﻿using codekey.service.service.abstracts;
using codekey.service.service.model;
using codekey.service.shared.exception.model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace codekey.service.api.controllers
{
    [Route("maintenance/v{version:apiVersion}/codekey/codekeys")]
    public class CodeKeyController : CodeKeyControllerBase
    {
        private readonly ILogger<CodeKeyController> _logger;
        private readonly ICodeKeyService _codeKeyService;
        private BadRequestObjectResult _badRequestObjectResult;
        private NotFoundObjectResult _notFoundObjectResult;
        public CodeKeyController(ICodeKeyService codeKeyService, ILogger<CodeKeyController> logger)
        {
            _codeKeyService = codeKeyService ?? throw new ArgumentNullException(nameof(codeKeyService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyLogModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
              Summary = "List CodeKeys",
              Description = "List CodeKeys")
             ]
        public async Task<ActionResult<CodeKeyModel>> GetAllAsync()
        {

            var model = await _codeKeyService.FilterBy(x => true, null, null);
            return Ok(model);

        }
    }
}
