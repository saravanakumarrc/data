﻿using codekey.service.service.model;
using codekey.service.shared.exception.model;
using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace codekey.service.api.controllers
{
    public class CodeKeyControllerBase : Controller
    {
        protected BadRequestObjectResult CreateBadRequestError(string errorMessage)
        {
            return BadRequest(new ErrorModel
            {
                StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest),
                Message = errorMessage
            });
        }
        protected bool IsBadRequest(string id, out BadRequestObjectResult badRequestObjectResult)
        {
            badRequestObjectResult = null;
            if (string.IsNullOrEmpty(id))
            {
                badRequestObjectResult = BadRequest(new ErrorModel
                {
                    StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest),
                    Message = "Missing parameters"
                });

                return true;
            }
            return false;
        }

        protected bool IsBadRequest(string accountId, string codeKey, out BadRequestObjectResult badRequestObjectResult)
        {
            badRequestObjectResult = null;
            if (string.IsNullOrEmpty(accountId) || string.IsNullOrEmpty(codeKey))
            {
                badRequestObjectResult = BadRequest(new ErrorModel
                {
                    StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest),
                    Message = "Missing parameters"
                });

                return true;
            }
            return false;
        }

        protected bool IsBadRequest(TDocumentModel entityModel, out BadRequestObjectResult badRequestObjectResult)
        {
            badRequestObjectResult = null;
            if (entityModel == null)
            {
                badRequestObjectResult = BadRequest(new ErrorModel
                {
                    StatusCode = Convert.ToInt32(HttpStatusCode.BadRequest),
                    Message = "Missing parameters"
                });

                return true;
            }
            return false;
        }

        protected bool IsEntityNotFound(string id, TDocumentModel entityModel, out NotFoundObjectResult notFoundObjectResult)
        {
            notFoundObjectResult = null;
            if (entityModel == null)
            {
                notFoundObjectResult = NotFound(new ErrorModel
                {
                    StatusCode = Convert.ToInt32(HttpStatusCode.NotFound),
                    Message = $"Resource with this id {id} doesn't found."
                });
                return true;
            }
            return false;
        }
        protected bool IsEntityNotFound(string accountId, string instanceId, string orderId, TDocumentModel entityModel, out NotFoundObjectResult notFoundObjectResult)
        {
            notFoundObjectResult = null;
            if (entityModel == null)
            {
                notFoundObjectResult = NotFound(new ErrorModel
                {
                    StatusCode = Convert.ToInt32(HttpStatusCode.NotFound),
                    Message = $"Resource with this accountid {accountId},instanceid {instanceId} ,orderid {orderId} doesn't found."
                });
                return true;
            }
            return false;
        }
        protected bool IsEntityNotFound(string id, IEnumerable<TDocumentModel> entityModels, out NotFoundObjectResult notFoundObjectResult)
        {
            notFoundObjectResult = null;
            return IsEntityNotFound(id, entityModels.FirstOrDefault(), out notFoundObjectResult);
        }
    }
}
