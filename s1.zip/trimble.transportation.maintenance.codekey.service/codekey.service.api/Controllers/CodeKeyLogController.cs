﻿using codekey.service.service.abstracts;
using codekey.service.service.model;
using codekey.service.shared.exception.model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Net;
using System.Threading.Tasks;

namespace codekey.service.api.controllers
{
    [Route("maintenance/v{version:apiVersion}/codekey/codekeylogs")]
    public class CodeKeyLogController : CodeKeyControllerBase
    {
        private readonly ILogger<CodeKeyLogController> _logger;
        private readonly ICodeKeyLogService _codeKeyLogService;
        private BadRequestObjectResult _badRequestObjectResult;
        private NotFoundObjectResult _notFoundObjectResult;
        public CodeKeyLogController(ICodeKeyLogService codeKeyLogService, ILogger<CodeKeyLogController> logger)
        {
            _codeKeyLogService = codeKeyLogService ?? throw new ArgumentNullException(nameof(codeKeyLogService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyLogModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
              Summary = "List CodeKeyLogs",
              Description = "List CodeKeyLogs")
             ]
        public async Task<ActionResult<CodeKeyLogModel>> GetAllAsync()
        {

            var model = await _codeKeyLogService.FilterBy(x => true, null, null);
            return Ok(model);

        }

        [Route("~/maintenance/v{version:apiVersion}/codekey/codekeylogs/{Id}", Name = "GetCodeKeyLogsById"), HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
       Summary = "Get CodeKeyLog Value by Id",
       Description = "Get CodeKeyLog Value  based on given input")
   ]
        public async Task<ActionResult<List<CodeKeyValueModel>>> GetCodeKeyLogsById(string id)
        {
            if (base.IsBadRequest(id, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }


            var codeKeyLogValue = await _codeKeyLogService.FindOneAsync(model => model.Id == id);
            if (codeKeyLogValue != null)
            {
                return Ok(codeKeyLogValue);
            }

            if (base.IsEntityNotFound(id, codeKeyLogValue, out _notFoundObjectResult))
            {
                return _notFoundObjectResult;
            }
            IsEntityNotFound(id, codeKeyLogValue, out _notFoundObjectResult);

            return _notFoundObjectResult;
        }

        [Route("~/maintenance/v{version:apiVersion}/codekey/accounts/{accountId}/codekeylogs", Name = "GetCodeKeyLogsByAccount"), HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyLogModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
            Summary = "Get CodeKey Logs By Account",
            Description = "Get CodeKey Logs By Account")
           ]
        public async Task<ActionResult<List<CodeKeyLogModel>>> GetCodeKeyLogsByAccount(string accountId,string eventId)
        {
            if (base.IsBadRequest(accountId, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }

            var codekeylogs = await _codeKeyLogService.FindByAccountId(accountId,eventId);
            if (base.IsEntityNotFound(accountId, codekeylogs, out _notFoundObjectResult))
            {
                IsEntityNotFound(accountId, entityModel: null, out _notFoundObjectResult);
                return _notFoundObjectResult;
            }
            return Ok(codekeylogs);
        }

        [HttpPost]
        [ProducesResponseType(typeof(CodeKeyLogModel), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [SwaggerOperation(
         Summary = "Create New CodeKey Log",
         Description = "Create CodeKeyLog For The Given Account")
           ]
        public async Task<ActionResult<CodeKeyLogModel>> PostAsync([FromBody]CodeKeyLogModel CodekeyLogModel)
        {
            if (IsBadRequest(CodekeyLogModel, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }
            if (CodekeyLogModel.CreatedDate == null)
            {
                CodekeyLogModel.CreatedDate = DateTime.Now;
            }
            CodeKeyLogModel result = await _codeKeyLogService.InsertOneAsync(CodekeyLogModel);
            return CreatedAtRoute("GetCodeKeyLogsById", new { id = result.Id }, result);
        }
    }
}
