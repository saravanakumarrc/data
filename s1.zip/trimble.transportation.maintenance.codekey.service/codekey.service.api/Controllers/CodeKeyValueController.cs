﻿using codekey.service.data.entities;
using codekey.service.service.abstracts;
using codekey.service.service.model;
using codekey.service.shared.constants.paging;
using codekey.service.shared.exception.model;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using Swashbuckle.AspNetCore.Annotations;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Net;
using System.Threading.Tasks;

namespace codekey.service.api.controllers
{
    [Route("maintenance/v{version:apiVersion}/codekey/codekeyvalues")]
    public class CodeKeyValueController : CodeKeyControllerBase
    {
        private readonly ILogger<CodeKeyValueController> _logger;
        private readonly ICodeKeyValueService _codeKeyValueService;
        private BadRequestObjectResult _badRequestObjectResult;
        private NotFoundObjectResult _notFoundObjectResult;
        public CodeKeyValueController(ICodeKeyValueService codeKeyService, ILogger<CodeKeyValueController> logger)
        {
            _codeKeyValueService = codeKeyService ?? throw new ArgumentNullException(nameof(codeKeyService));
            _logger = logger ?? throw new ArgumentNullException(nameof(logger));
        }

        [HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
              Summary = "List CodeKey Values",
              Description = "List CodeKey Values")
             ]
        public async Task<ActionResult<CodeKeyValueModel>> GetAllAsync()
        {

            var model = await _codeKeyValueService.FilterBy(x => true, null, null);
            return Ok(model);

        }

        [Route("~/maintenance/v{version:apiVersion}/codekey/codekeyvalues/{Id}", Name = "GetByIdAsync"), HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
            Summary = "Get CodeKey Value by Id",
            Description = "Get CodeKey Value  based on given input")
        ]
        public async Task<ActionResult<List<CodeKeyValueModel>>> GetByIdAsync(string id)
        {
            if (base.IsBadRequest(id, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }


            var codeKeyValue = await _codeKeyValueService.FindOneAsync(model => model.Id == id);
            if (codeKeyValue != null)
            {
                return Ok(codeKeyValue);
            }

            if (base.IsEntityNotFound(id, codeKeyValue, out _notFoundObjectResult))
            {
                return _notFoundObjectResult;
            }
            IsEntityNotFound(id, codeKeyValue, out _notFoundObjectResult);

            return _notFoundObjectResult;
        }


        [Route("~/maintenance/v{version:apiVersion}/codekey/accounts/{accountId}/codekeyvalues", Name = "GetByAccountIdAsync"), HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
            Summary = "Get CodeKey Value by AccountId",
            Description = "Get CodeKey Value  based on given input")
           ]
        public async Task<ActionResult<List<CodeKeyValueModel>>> GetByAccountIdAsync(string accountId)
        {
            if (base.IsBadRequest(accountId, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }


            var codeKeyValue = await _codeKeyValueService.FindByAccountId(accountId);
            if (codeKeyValue != null && codeKeyValue.Count() > 0)
            {
                return Ok(codeKeyValue);
            }

            if (base.IsEntityNotFound(accountId, codeKeyValue, out _notFoundObjectResult))
            {
                return _notFoundObjectResult;
            }
            IsEntityNotFound(accountId, codeKeyValue, out _notFoundObjectResult);
            return _notFoundObjectResult;

        }

        [Route("~/maintenance/v{version:apiVersion}/codekey/accounts/{accountId}/codekeyvalues/{codeKey}/datavalues", Name = "GetDataValueAsync"), HttpGet]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.OK)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
            Summary = "Get Data Values by AccountId and code key",
            Description = "Get Data Values by AccountId and code key")
           ]
        public async Task<ActionResult<PagedResponseList<DataValueModel>>> GetDataValueAsync(string accountId, string codeKey, [FromQuery] QueryStringParams queryStringParams)
        {
            if (base.IsBadRequest(accountId,codeKey, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }

            var dataValues = await _codeKeyValueService.GetDataValuesAsync(accountId, codeKey, queryStringParams);
            if (dataValues?.Data?.Count() > 0)
            {
                return Ok(dataValues);
            }

            if (IsEntityNotFound(accountId, codeKey, dataValues?.Data, out _notFoundObjectResult))
            {
                return _notFoundObjectResult;
            }

            return _notFoundObjectResult;

        }

        [HttpPost]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.Created)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [SwaggerOperation(
         Summary = "Create CodeKey Value",
         Description = "Create CodeKey Value For The Given Account and Mapping Key")
           ]
        public async Task<ActionResult<CodeKeyValueModel>> PostAsync([FromBody] CodeKeyValueModel codeKeyValueModel)
        {
            if (IsBadRequest(codeKeyValueModel, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }
            if (codeKeyValueModel.CreatedDate == null)
            {
                codeKeyValueModel.CreatedDate = DateTime.Now;
            }
            CodeKeyValueModel result = await _codeKeyValueService.InsertOneAsync(codeKeyValueModel);
            return CreatedAtRoute("GetByIdAsync", new { Id = result.Id }, result);
        }
        [HttpPut]
        [ProducesResponseType(typeof(CodeKeyValueModel), (int)HttpStatusCode.Accepted)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [SwaggerOperation(
                   Summary = "Update CodeKeyValue Model",
                   Description = "Update CodeKeyValue Model")
           ]
        public async Task<ActionResult<object>> Update([FromBody] CodeKeyValueModel codeKeyValueModel)
        {

            if (IsBadRequest(codeKeyValueModel, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }

            _logger.LogInformation($"Put Async - Received CodeKeyValue Model {JsonConvert.SerializeObject(codeKeyValueModel)} ");

            var codeKeyValueFromDb = await _codeKeyValueService.FindOneAsync(model => model.Id == codeKeyValueModel.Id);

            if (codeKeyValueFromDb != null)
            {
                codeKeyValueModel.Id = codeKeyValueFromDb.Id;
                var isUpdated = await _codeKeyValueService.UpdateOneAsync(codeKeyValueModel);
                if (isUpdated != null)
                {
                    return AcceptedAtRoute("GetByIdAsync", new { Id = codeKeyValueModel.Id }, codeKeyValueModel);
                }
            }

            IsEntityNotFound(codeKeyValueModel.Id, entityModel: null, out _notFoundObjectResult);
            return _notFoundObjectResult;

        }

        [HttpDelete("{id}")]
        [ProducesResponseType((int)HttpStatusCode.NoContent)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.NotFound)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.BadRequest)]
        [ProducesResponseType(typeof(ErrorModel), (int)HttpStatusCode.InternalServerError)]
        [SwaggerOperation(
            Summary = "Delete CodeKey Value",
            Description = "Delete CodeKey Value")
            ]
        public async Task<ActionResult> Delete(string id)
        {
            if (base.IsBadRequest(id, out _badRequestObjectResult))
            {
                return _badRequestObjectResult;
            }

            await _codeKeyValueService.DeleteByIdAsync(id);
            return NoContent();
        }

        private bool IsEntityNotFound<TArrayElementModel>(string accountId, string codeKey, IEnumerable<TArrayElementModel> entityModels, out NotFoundObjectResult notFoundObjectResult)
        {
            notFoundObjectResult = null;
            if (entityModels == null || entityModels.Count() == 0)
            {
                notFoundObjectResult = NotFound(new ErrorModel
                {
                    StatusCode = Convert.ToInt32(HttpStatusCode.NotFound),
                    Message = $"Resource with this accountid {accountId}, CodeKey {codeKey} doesn't found."
                });
                return true;
            }
            return false;
        }
    }
}
