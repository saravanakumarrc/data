using codekey.service.repository;
using codekey.service.repository.abstracts;
using codekey.service.repository.config;
using codekey.service.service.abstracts;
using codekey.service.service.mapping;
using codekey.service.shared.constants;
using codekey.service.shared.exception.extensions;
using codekey.service.shared.exception.model;
using Microsoft.AspNetCore.Builder;
using Microsoft.AspNetCore.Hosting;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Configuration;
using Microsoft.Extensions.DependencyInjection;
using Microsoft.Extensions.Hosting;
using Microsoft.Extensions.Options;
using Microsoft.OpenApi.Models;
using Serilog;
using Serilog.Core;
using Serilog.Events;
using Serilog.Templates;
using System;
using System.IO;
using System.Linq;

namespace codekey.service.api
{
    public class Startup
    {
        private string _environment = "local";
        public Startup(IConfiguration configuration)
        {
            _environment = Environment.GetEnvironmentVariable(AppConstants.Environment);
            Configuration = new ConfigurationBuilder()
                          .SetBasePath(Directory.GetCurrentDirectory())
                          .AddJsonFile($"appsettings.{_environment}.json", false, true)
                          .AddEnvironmentVariables().Build();

            var loggingLevel = Configuration["SeriLog:MinimumLevel:Default"];
            var levelSwitch = new LoggingLevelSwitch();
            levelSwitch.MinimumLevel = String.IsNullOrEmpty(loggingLevel) ?
                                        LogEventLevel.Information :
                                        (LogEventLevel)Enum.Parse(typeof(LogEventLevel), loggingLevel);

            Log.Logger = new LoggerConfiguration()
                                .ReadFrom.Configuration(Configuration)
                                .MinimumLevel.ControlledBy(levelSwitch)
                                .Enrich.FromLogContext()
                                .Enrich.WithCorrelationIdHeader(AppConstants.CorrelationId)
                                .WriteTo.Console(new ExpressionTemplate(
                                 "{ {..@p , @l: if @l = 'Information' then undefined() else @l,@m,@x,@sc: SourceContext, @t:UtcDateTime(@t),  SourceContext: undefined()} }\n"))
                                .CreateLogger();

            Log.Information("Microservice Started in the Environment" + _environment);
        }

        public IConfiguration Configuration { get; }

        // This method gets called by the runtime. Use this method to add services to the container.
        public void ConfigureServices(IServiceCollection services)
        {
            services.AddHttpContextAccessor();

            services.AddControllers();
            services.AddSwaggerGen(c =>
            {
                c.SwaggerDoc("v1", new OpenApiInfo { Title = "codekey.service", Version = "v1" });
                c.EnableAnnotations();
            });

            services.AddCors(c =>
            {
                c.AddPolicy("CorsPolicy", options =>
                {
                    options.AllowAnyOrigin()
                           .AllowAnyHeader();
                });
            });
            services.AddApiVersioning(opt =>
            {
                // Provides the different api version in response header
                opt.ReportApiVersions = true;
                // this configuration will allow the api to automaticaly take api_version=1.0 in case it was not specify
                opt.AssumeDefaultVersionWhenUnspecified = true;
                // We are giving the default version of 1.0 to the api
                opt.DefaultApiVersion = ApiVersion.Default; // new ApiVersion(1, 0);
            });
            services.Configure<DatabaseSettings>(options => Configuration.GetSection("DatabaseSettings").Bind(options))
                    .AddSingleton<IDatabaseSettings>(serviceProvider => serviceProvider.GetRequiredService<IOptions<DatabaseSettings>>().Value)
                    .AddSingleton(typeof(IMongoDBContext), typeof(MongoDBContext))
                    .AddSingleton(AutoMapperConfiguration.Configure())
                    .AddScoped(typeof(IMongoRepository<>), typeof(MongoRepository<>))
                    .AddScoped(typeof(ICodeKeyValueRepository), typeof(CodeKeyValueRepository))
                    .AddHttpClient();
            RegisterService<ICodeKeyValueService>(services);

        }


        private static void RegisterService<T>(IServiceCollection services) where T : class
        {
            var assembly = typeof(T).Assembly;
            var types = assembly.ExportedTypes.Where(x => x.IsClass && x.IsPublic);
            foreach (var type in types)
            {
                if (type.GetInterface($"I{type.Name}") != null)
                {
                    services.AddScoped(type.GetInterface($"I{type.Name}"), type);
                }
            }
        }

        // This method gets called by the runtime. Use this method to configure the HTTP request pipeline.
        public void Configure(IApplicationBuilder app, IWebHostEnvironment env)
        {
            if (env.IsDevelopment())
            {
                app.UseDeveloperExceptionPage();
                app.UseSwagger();
                app.UseSwaggerUI(c => c.SwaggerEndpoint("/swagger/v1/swagger.json", "codekey.service v1"));
            }

            app.ConfigureCustomExceptionMiddleware(new ExceptionOption() { EnableTrace = Convert.ToBoolean(Environment.GetEnvironmentVariable(AppConstants.LogTrace)) });

            app.UseRouting();

            // This line should be place between the UseRouting() and UseEndpoints() in order to support cross orgin request.
            app.UseCors("CorsPolicy");

            app.UseAuthorization();

            app.UseEndpoints(endpoints =>
            {
                endpoints.MapControllers();
            });
        }
    }
}
