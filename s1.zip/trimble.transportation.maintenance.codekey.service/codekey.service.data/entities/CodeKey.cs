﻿using codekey.service.data.utilities;
using MongoDB.Bson.Serialization.Attributes;
using System.Reflection.Metadata;

namespace codekey.service.data.entities
{
    [BsonCollection("code_keys")]
    public class CodeKey : TDocument
    {
        [BsonElement("mapping_key")]
        public string MappingKey { get; set; }
        [BsonElement("resource_url")]
        public string ResourceUrl { get; set; }
        [BsonElement("data_mapping")]
        public DataMapping DataMapping { get; set; }
        [BsonElement("is_active")]
        public bool IsActive { get; set; }
        [BsonElement("search_url")]
        public string SearchUrl { get; set; }
    }

    public class DataMapping
    {
        [BsonElement("code_id")]
        public string CodeId { get; set; }

        [BsonElement("code")]
        public string Code { get; set; }

        [BsonElement("description")]
        public string Description { get; set; }
    }
}
