﻿using codekey.service.data.utilities;
using MongoDB.Bson.Serialization.Attributes;

namespace codekey.service.data.entities
{
    [BsonCollection("code_key_logs")]
    public class CodeKeyLog : TDocument
    {
        [BsonElement("account_id")]
        public string AccountId { get; set; }
        [BsonElement("event_id")]
        public string EventId { get; set; }
        [BsonElement("status")]
        public string Status { get; set; }
        [BsonElement("details")]
        public CodeKeyLogDetail[] Details { get; set; }
    }

    [BsonCollection("details")]
    public class CodeKeyLogDetail
    {
        public string MappingKey { get; set; }
        public int StatusCode { get; set; }
        public string Error { get; set; }
    }
}
