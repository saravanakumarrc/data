﻿using codekey.service.data.utilities;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;

namespace codekey.service.data.entities
{
    [BsonCollection("code_key_values")]
    public class CodeKeyValue : TDocument
    {
        [BsonElement("account_id")]
        public string AccountId { get; set; }

        [BsonElement("mapping_key")]
        public string MappingKey { get; set; }

        [BsonElement("is_active")]
        public bool IsActive { get; set; }

        [BsonElement("data_values")]
        public IList<DataValue> DataValues { get; set; }
    }

    [BsonCollection("data_values")]
    public class DataValue
    {
        [BsonElement("code_id")]
        public string CodeId { get; set; }

        [BsonElement("code")]
        public string Code { get; set; }

        [BsonElement("description")]
        public string Description { get; set; }
    }

}
