﻿using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.shared.constants.paging;
using MongoDB.Bson.Serialization;
using MongoDB.Bson;
using MongoDB.Driver;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Text.RegularExpressions;
using codekey.service.repository.helpers;

namespace codekey.service.repository
{
    public class CodeKeyValueRepository : MongoRepository<CodeKeyValue>, ICodeKeyValueRepository
    {
        public CodeKeyValueRepository(IMongoDBContext dbContext) : base(dbContext)
        {
        }

        public async Task<PagedResponseList<DataValue>> GetDataValuesAsync(string accountId, string codeKey, QueryStringParams queryStringParams)
        {
            PipelineDefinition<CodeKeyValue, BsonDocument> codeMatchPipeline = new BsonDocument[]
            {
                PipelineHelpers.BuildMatchClause(new List<Filtering>{ 
                    new Filtering { Field="account_id", Value = accountId }, 
                    new Filtering { Field = "mapping_key", Value = codeKey } 
                }),
                PipelineHelpers.BuildUnWindClause("data_values"),
                PipelineHelpers.BuildMatchClause(queryStringParams?.Filter,"data_values"),
                PipelineHelpers.BuildSortClause(queryStringParams?.SortBy ?? new List<Sorting>{ new Sorting { Field = "code", Dir = "asc" } }, "data_values"),
                PipelineHelpers.BuildGroupClause("data_values")
            };

            var matchResult = await AggregateAsync(codeMatchPipeline);

            if (matchResult?.Count > 0)
            {
                var resultDocument = matchResult[0];

                var codeKeyValue = BsonSerializer.Deserialize<CodeKeyValue>(resultDocument);

                return PagedResponseList<DataValue>.ToPagedResponseList(codeKeyValue.DataValues?.ToList() ?? new List<DataValue>(), queryStringParams);
            }
            return null;
        }

        
    }
}
