﻿using codekey.service.data.utilities;
using codekey.service.repository.abstracts;
using MongoDB.Driver;
using System;
using System.Linq;

namespace codekey.service.repository
{
    /// <summary>
    /// RepairService - Mongo database context
    /// </summary>
    public class MongoDBContext : IMongoDBContext
    {
        private IMongoDatabase Database { get; set; }
        private MongoClient MongoClient { get; set; }


        public MongoDBContext(IDatabaseSettings databaseSettings)
        {
            var clientSettings = MongoClientSettings.FromConnectionString(databaseSettings.ConnectionString);
            MongoClient = new MongoClient(clientSettings);
            Database = MongoClient.GetDatabase(databaseSettings.DatabaseName);
        }

        public IMongoCollection<T> GetCollection<T>(Type collectionType)
        {
            return Database.GetCollection<T>(GetCollectionName(collectionType));
        }

        private protected string GetCollectionName(Type documentType)
        {
            return ((BsonCollectionAttribute)documentType.GetCustomAttributes(
                    typeof(BsonCollectionAttribute),
                    true)
                .FirstOrDefault())?.CollectionName;
        }
    }


}
