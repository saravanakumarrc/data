﻿using codekey.service.data.entities;
using codekey.service.shared.constants.paging;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codekey.service.repository.abstracts
{
    public interface ICodeKeyValueRepository : IMongoRepository<CodeKeyValue>
    {
        Task<PagedResponseList<DataValue>> GetDataValuesAsync(string accountId, string codeKey, QueryStringParams queryStringParams);
    }
}
