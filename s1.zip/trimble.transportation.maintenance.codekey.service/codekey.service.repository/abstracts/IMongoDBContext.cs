﻿using MongoDB.Driver;
using System;

namespace codekey.service.repository.abstracts
{
    public interface IMongoDBContext
    {
        IMongoCollection<T> GetCollection<T>(Type collectionType);
    }
}
