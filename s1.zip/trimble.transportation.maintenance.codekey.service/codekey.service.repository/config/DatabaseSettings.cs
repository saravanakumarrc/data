﻿using codekey.service.repository.abstracts;

namespace codekey.service.repository.config
{
    public class DatabaseSettings : IDatabaseSettings
    {
        public string DatabaseName { get; set; }
        public string ConnectionString { get; set; }
        public DatabaseSettings() { }
    }
}
