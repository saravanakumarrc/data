﻿using codekey.service.shared.constants.paging;
using MongoDB.Bson;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;

namespace codekey.service.repository.helpers
{
    public class PipelineHelpers
    {
        public static BsonDocument BuildGroupClause(string arrayElement)
        {
            return new BsonDocument("$group",
                new BsonDocument
                    {
                        { "_id", "$_id" },
                        { arrayElement, new BsonDocument("$push", $"${arrayElement}") }
                    });
        }

        public static BsonDocument BuildUnWindClause(string arrayElement)
        {
            return new BsonDocument("$unwind", $"${arrayElement}");
        }

        public static BsonDocument BuildMatchClause(List<Filtering> filters, string fieldPrefix = null)
        {
            var matchConditions = new BsonDocument();

            if(filters != null)
            {
                foreach (var filter in filters)
                {
                    if (!string.IsNullOrEmpty(fieldPrefix))
                    {
                        filter.Field = $"{fieldPrefix}.{filter.Field}";
                    }
                    matchConditions.AddRange(BuildMatchDocument(filter));
                }
            }            

            return new BsonDocument("$match", matchConditions);
        }

        public static BsonDocument BuildMatchDocument(Filtering filtering)
        {
            BsonDocument filter;
            switch (filtering.Operator?.ToLower())
            {
                case "eq":
                    filter = new BsonDocument("$eq", filtering.Value);
                    break;
                case "neq":
                    filter = new BsonDocument("$neq", filtering.Value);
                    break;
                case "contains":
                    filter = new BsonDocument
                    {
                        {"$regex", new Regex(".*" + filtering.Value + ".*")},
                        {"$options", "i"}
                    };
                    break;
                case "startswith":
                    filter = new BsonDocument
                    {
                        {"$regex", new Regex("^" + filtering.Value)},
                        {"$options", "i"}
                    };
                    break;
                case "endswith":
                    filter = new BsonDocument
                    {
                        {"$regex", new Regex(filtering.Value + "$")},
                        {"$options", "i"}
                    };
                    break;
                default:
                    filter = new BsonDocument("$eq", filtering.Value);
                    break;
            }
            var match = new BsonDocument(filtering.Field,
                filter);
            return match;
        }

        public static BsonDocument BuildSortClause(List<Sorting> sortByList, string fieldPrefix = null)
        {
            var sortConditions = new BsonDocument();

            if (sortByList != null)
            {
                foreach (var sorting in sortByList)
                {
                    if (!string.IsNullOrEmpty(fieldPrefix))
                    {
                        sorting.Field = $"{fieldPrefix}.{sorting.Field}";
                    }
                    sortConditions.Add(new BsonElement(sorting.Field, sorting.Dir?.ToLower() == "desc" ? -1 : 1));
                }
            }

            return new BsonDocument("$sort", sortConditions);
        }
    }
}
