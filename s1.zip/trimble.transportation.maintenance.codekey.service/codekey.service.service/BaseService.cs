﻿using AutoMapper;
using codekey.service.data.abstracts;
using codekey.service.repository.abstracts;
using codekey.service.service.abstracts;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace codekey.service.service
{
    public class BaseService<TModel, TDocument> where TModel : IDocumentModel, new()
                                                      where TDocument : IDocument, new()
    {
        #region Class Variables
        private readonly IMongoRepository<TDocument> _repository;
        private readonly IMapper _mapper;

        #endregion

        #region Constructor 
        public BaseService(IMongoRepository<TDocument> repository,
            IMapper mapper)
        {
            _repository = repository;
            _mapper = mapper;
        }
        #endregion

        #region Methods


        public virtual async Task<IEnumerable<TModel>> FilterBy(Expression<Func<TDocument, bool>> filterExpression, int? skip, int? limit)
        {
            var result = await _repository.FilterBy(filterExpression, skip, limit);
            return _mapper.Map<IEnumerable<TDocument>, IEnumerable<TModel>>(result);
        }

        public virtual async Task<IEnumerable<TProjected>> FilterBy<TProjected>(
            Expression<Func<TDocument, bool>> filterExpression,
            Expression<Func<TDocument, TProjected>> projectionExpression)
        {
            var result = await _repository.FilterBy(filterExpression, projectionExpression);
            return result;
        }

        public virtual async Task<TModel> FindOneAsync(Expression<Func<TDocument, bool>> filterExpression)
        {
            var result = await _repository.FindOneAsync(filterExpression);
            return _mapper.Map<TDocument, TModel>(result);
        }
        public virtual async Task<IEnumerable<TDocument>> FindAll(Expression<Func<TDocument, bool>> filterExpression)
        {
            var result = await _repository.FindOneAsync(filterExpression);
            return _mapper.Map<TDocument, IEnumerable<TDocument>>(result);
        }

        public virtual async Task<TModel> InsertOneAsync(TModel model)
        {
            var result = await _repository.InsertOneAsync(
                _mapper.Map<TModel, TDocument>(model));
            return _mapper.Map<TDocument, TModel>(result);
        }

        public virtual async Task<TModel> FindByIdAsync(string id)
        {
            TDocument document = await _repository.FindByIdAsync(id);
            return _mapper.Map<TDocument, TModel>(document);
        }

        public virtual async Task<TModel> ReplaceOneAsync(TModel model)
        {
            var result = await _repository.ReplaceOneAsync(
                        _mapper.Map<TModel, TDocument>(model));
            return _mapper.Map<TDocument, TModel>(result);
        }
        public async Task<bool> UpdateAsync(TModel model)
        {
            TDocument document = _mapper.Map<TModel, TDocument>(model);
            return await _repository.UpdateAsync(document);
        }

        public virtual async Task<TDocument> DeleteByIdAsync(string id)
        {
            return await _repository.DeleteByIdAsync(id);
        }

       


        #endregion
    }
}

