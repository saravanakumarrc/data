﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.service.abstracts;
using codekey.service.service.model;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace codekey.service.service
{
    public class CodeKeyLogService : BaseService<CodeKeyLogModel, CodeKeyLog>, ICodeKeyLogService
    {
        private readonly ILogger<ICodeKeyLogService> _logger;
        public CodeKeyLogService(ILogger<ICodeKeyLogService> logger,
                                  IMongoRepository<CodeKeyLog> repository,
                                  IMapper mapper) : base(repository, mapper)
        {
            _logger = logger;
        }

        public async Task<CodeKeyLogModel> FindOneAsync(string accountId)
        {
            return await base.FindOneAsync(model => model.AccountId == accountId);
        }
        public async Task<IEnumerable<CodeKeyLogModel>> FindByAccountId(string accountId,string eventId)
        {
            var result = new List<CodeKeyLogModel>(); 
            if (string.IsNullOrEmpty(eventId))
            {
                result = (List<CodeKeyLogModel>)await FilterBy(model => model.AccountId == accountId, null, null);
            }
            else
            {
                result = (List<CodeKeyLogModel>)await FilterBy(model => model.AccountId == accountId && model.EventId == eventId, null, null);
            }
            return result;
        }
    }
}
