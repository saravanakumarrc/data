﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.service.abstracts;
using codekey.service.service.model;
using Microsoft.Extensions.Logging;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace codekey.service.service
{
    public class CodeKeyService : BaseService<CodeKeyModel, CodeKey>, ICodeKeyService
    {
        private readonly ILogger<ICodeKeyLogService> _logger;
        public CodeKeyService(ILogger<ICodeKeyLogService> logger,
                                  IMongoRepository<CodeKey> repository,
                                  IMapper mapper) : base(repository, mapper)
        {
            _logger = logger;
        }
    }
}
