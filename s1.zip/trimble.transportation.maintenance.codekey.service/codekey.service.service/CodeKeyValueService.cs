﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.service.abstracts;
using codekey.service.service.model;
using codekey.service.shared.constants.paging;
using Microsoft.Extensions.Logging;
using MongoDB.Bson;
using MongoDB.Bson.Serialization;
using MongoDB.Driver;
using Newtonsoft.Json;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace codekey.service.service
{
    public class CodeKeyValueService : BaseService<CodeKeyValueModel, CodeKeyValue>, ICodeKeyValueService
    {
        private readonly ILogger<ICodeKeyValueService> _logger;
        private readonly ICodeKeyValueRepository _repository;
        private readonly IMapper _mapper;
        public CodeKeyValueService(ILogger<ICodeKeyValueService> logger,
                                  ICodeKeyValueRepository repository,
                                  IMapper mapper) : base(repository, mapper)
        {
            _logger = logger;
            _repository = repository;
            _mapper = mapper;
        }

        public async Task<CodeKeyValueModel> FindOneAsync(string accountId)
        {
            return await base.FindOneAsync(model => model.AccountId == accountId);
        }
        public async Task<IEnumerable<CodeKeyValueModel>> FindByAccountId(string accountId)
        {
            var result = await FilterBy(model => model.AccountId == accountId, model => new CodeKeyValueModel
            {
                AccountId = model.AccountId,
                CreatedBy = model.CreatedBy,
                Id = model.Id,
                CreatedDate = model.CreatedDate,
                IsActive = model.IsActive,
                MappingKey = model.MappingKey,
                ModifiedBy = model.ModifiedBy,
                ModifiedDate = model.ModifiedDate
            });
            return result;
        }
        public async ValueTask<CodeKeyValueModel> UpdateOneAsync(CodeKeyValueModel model)
        {
            if (model.ModifiedDate == null)
                model.ModifiedDate = DateTime.Now;

            return await ReplaceOneAsync(model);
        }

        public async Task<PagedResponseList<DataValueModel>> GetDataValuesAsync(string accountId, string codeKey, QueryStringParams queryStringParams)
        {
            var dataValues = await _repository.GetDataValuesAsync(accountId, codeKey, queryStringParams); 

            return _mapper.Map<PagedResponseList<DataValueModel>>(dataValues);
        }
    }
}
