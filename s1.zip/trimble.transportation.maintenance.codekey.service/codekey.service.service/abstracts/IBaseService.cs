﻿using codekey.service.data.abstracts;
using System;
using System.Collections.Generic;
using System.Linq.Expressions;
using System.Threading.Tasks;

namespace codekey.service.service.abstracts
{
    public interface IBaseService<TModel, TDocument> where TModel : IDocumentModel, new()
                                                      where TDocument : IDocument, new()
    {
        Task<TModel> FindOneAsync(Expression<Func<TDocument, bool>> filterExpression);
        Task<IEnumerable<TDocument>> FindAll(Expression<Func<TDocument, bool>> filterExpression);
        Task<IEnumerable<TModel>> FilterBy(Expression<Func<TDocument, bool>> filterExpression, int? skip, int? limit);
        Task<TModel> InsertOneAsync(TModel model);
        Task<TModel> FindByIdAsync(string id);
        Task<TModel> ReplaceOneAsync(TModel model);
        Task<bool> UpdateAsync(TModel model);
        Task<TDocument> DeleteByIdAsync(string id);
    }
}
