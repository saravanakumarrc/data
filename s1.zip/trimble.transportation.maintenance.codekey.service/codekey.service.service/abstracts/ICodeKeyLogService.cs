﻿using codekey.service.data.entities;
using codekey.service.service.model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace codekey.service.service.abstracts
{
    public interface ICodeKeyLogService : IBaseService<CodeKeyLogModel, CodeKeyLog>
    {
        Task<CodeKeyLogModel> FindOneAsync(string accountId);
        Task<IEnumerable<CodeKeyLogModel>> FindByAccountId(string accountId,string eventId);
    }
}
