﻿using codekey.service.data.entities;
using codekey.service.service.model;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace codekey.service.service.abstracts
{
    public interface ICodeKeyService : IBaseService<CodeKeyModel, CodeKey>
    {
    }
}
