﻿using codekey.service.data.entities;
using codekey.service.service.model;
using codekey.service.shared.constants.paging;
using System.Collections.Generic;
using System.Threading.Tasks;

namespace codekey.service.service.abstracts
{
    public interface ICodeKeyValueService : IBaseService<CodeKeyValueModel, CodeKeyValue>
    {
        Task<CodeKeyValueModel> FindOneAsync(string accountId);
        Task<IEnumerable<CodeKeyValueModel>> FindByAccountId(string accountId);
        Task<PagedResponseList<DataValueModel>> GetDataValuesAsync(string accountId, string codeKey, QueryStringParams queryStringParams);
        ValueTask<CodeKeyValueModel> UpdateOneAsync(CodeKeyValueModel model);
    }
}
