﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.service.model;
using codekey.service.shared.constants.paging;

namespace codekey.service.service.mapping
{
    public class DomainToModelMappingProfile : Profile
    {
        public DomainToModelMappingProfile()
        {
            CreateMap<TDocument, TDocumentModel>();
            CreateMap<CodeKeyValue, CodeKeyValueModel>();
            CreateMap<DataValue, DataValueModel>();
            CreateMap<PagedResponseList<DataValue>, PagedResponseList<DataValueModel>>();
            CreateMap<PagingInfo<DataValue>, PagingInfo<DataValueModel>>();
            CreateMap<CodeKeyLog, CodeKeyLogModel>();
            CreateMap<CodeKeyLogDetail, CodeKeyLogDetailModel>();
            CreateMap<CodeKey, CodeKeyModel>();
            CreateMap<DataMapping, DataMappingModel>();
        }
    }
}
