﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.service.model;
using codekey.service.shared.constants.paging;

namespace codekey.service.service.mapping
{
    public class ModelToDomainMappingProfile : Profile
    {
        public ModelToDomainMappingProfile()
        {
            CreateMap<TDocumentModel, TDocument>();
            CreateMap<CodeKeyValueModel, CodeKeyValue>();
            CreateMap<DataValueModel, DataValue>();
            CreateMap<CodeKeyLogModel, CodeKeyLog>();
            CreateMap<CodeKeyLogDetailModel, CodeKeyLogDetail>();
            CreateMap<PagedResponseList<DataValueModel>, PagedResponseList<DataValue>>();
            CreateMap<PagingInfo<DataValueModel>, PagingInfo<DataValue>>();
            CreateMap<CodeKeyModel, CodeKey>();
            CreateMap<DataMappingModel, DataMapping>();
        }
    }
}
