﻿using codekey.service.data.entities;
using MongoDB.Bson.Serialization.Attributes;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codekey.service.service.model
{
    public class CodeKeyModel : TDocumentModel
    {
        public string MappingKey { get; set; }
        public string ResourceUrl { get; set; }
        public DataMappingModel DataMapping { get; set; }
        public bool IsActive { get; set; }
        public string SearchUrl { get; set; }
    }
    public class DataMappingModel
    {
        public string CodeId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
    }
}
