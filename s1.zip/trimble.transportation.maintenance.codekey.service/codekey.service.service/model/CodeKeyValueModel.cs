﻿using codekey.service.data.entities;
using System;
using System.Collections.Generic;

namespace codekey.service.service.model
{
    public class CodeKeyValueModel : TDocumentModel
    {
        public string AccountId { get; set; }
        public string MappingKey { get; set; }
        public bool IsActive { get; set; }
        public IList<DataValueModel> DataValues { get; set; }
    }
    public class DataValueModel
    {
        public string CodeId { get; set; }
        public string Code { get; set; }
        public string Description { get; set; }
    }
   
}
