﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace codekey.service.service.model
{
    public class CodeKeyLogModel : TDocumentModel
    {
        public string AccountId { get; set; }
        public string EventId { get; set; }
        public string Status { get; set; }
        public CodeKeyLogDetailModel[] Details { get; set; }
    }
    public class CodeKeyLogDetailModel
    {
        public string MappingKey { get; set; }
        public int StatusCode { get; set; }
        public string Error { get; set; }
    }
}
