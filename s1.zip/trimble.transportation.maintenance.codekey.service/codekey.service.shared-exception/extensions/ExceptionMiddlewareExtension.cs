﻿using codekey.service.shared.exception.middleware;
using codekey.service.shared.exception.model;
using Microsoft.AspNetCore.Builder;

namespace codekey.service.shared.exception.extensions
{
    /// <summary>
    /// Extension class of IApplicationBuilder class and used register the ExceptionMiddleware type.
    /// </summary>
    public static class ExceptionMiddlewareExtension
    {
        public static void ConfigureCustomExceptionMiddleware(this IApplicationBuilder app, ExceptionOption option)
        {
            app.UseMiddleware<ExceptionMiddleware>(option);
        }

    }
}
