﻿
namespace codekey.service.shared.exception.model
{
    public class ExceptionOption
    {
        public bool EnableTrace { get; set; }
    }
}
