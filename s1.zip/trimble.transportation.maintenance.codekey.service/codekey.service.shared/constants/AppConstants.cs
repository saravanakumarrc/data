﻿
namespace codekey.service.shared.constants
{
    public static class AppConstants
    {
        public const string Environment = "ENV";
        public const string CorrelationId = "x-correlation-id";
        public const string LogTrace = "LOG_TRACE";
    }
}
