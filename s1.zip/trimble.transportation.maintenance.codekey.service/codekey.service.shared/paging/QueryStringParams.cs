﻿using System.Collections.Generic;
    
namespace codekey.service.shared.constants.paging
{
    public class QueryStringParams
    {
        const int maxPageSize = 50;
        public virtual int PageNo { get; set; }
        private  int _pageSize;
        public virtual int PageSize
        {
            get => _pageSize;
            set => _pageSize = (value > maxPageSize) ? maxPageSize : value;
        }       
        public virtual List<Sorting> SortBy { get; set; }

        public virtual List<Filtering> Filter { get; set;}
    }

    public class Sorting
    {
        public string Field { get; set; }
        public string Dir { get; set; }
    }
    public class Filtering
    {
        public string Field { get; set; }
        public string Operator { get; set; }
        public string Value { get; set; }
    }
}
