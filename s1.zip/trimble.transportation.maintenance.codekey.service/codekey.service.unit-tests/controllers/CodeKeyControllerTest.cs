﻿using codekey.service.api.controllers;
using codekey.service.data.entities;
using codekey.service.service.model;
using codekey.service.unit.tests.mocks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace codekey.service.unit.tests.controllers
{
    public class CodeKeyControllerTest : IClassFixture<InitializeMockCodeKeyFixture>
    {
        readonly InitializeMockCodeKeyFixture _initializeMockCodeKeyFixture;

        public CodeKeyControllerTest(InitializeMockCodeKeyFixture initializeMockCodeKeyFixture)
        {
            _initializeMockCodeKeyFixture = initializeMockCodeKeyFixture;
        }
        
        #region GetById
        [Fact]
        public async Task CodeKeyController_GetAll_ReturnOkResult()
        {
            var CodeKeyModel = _initializeMockCodeKeyFixture.MockData.Object.MockCodeKeys();
            
            _initializeMockCodeKeyFixture.MockDataRepository.Setup(x => x.FilterBy(model => true, null, null))
               .ReturnsAsync(CodeKeyModel);

            var controller = new CodeKeyController(_initializeMockCodeKeyFixture.MockCodeKeyService.Object, new NullLogger<CodeKeyController>());

            var result = await controller.GetAllAsync();

            var resultObjectResult = result.Result as OkObjectResult;
            Assert.IsType<OkObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status200OK);
        }
        #endregion
    }
}
