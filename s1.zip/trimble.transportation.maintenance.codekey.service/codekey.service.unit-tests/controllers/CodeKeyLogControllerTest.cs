﻿using codekey.service.api.controllers;
using codekey.service.data.entities;
using codekey.service.service.model;
using codekey.service.unit.tests.mocks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace codekey.service.unit.tests.controllers
{
    public class CodeKeyLogControllerTest : IClassFixture<InitializeMockCodeKeyLogFixture>
    {
        readonly InitializeMockCodeKeyLogFixture _initializeMockCodeKeyLogFixture;

        public CodeKeyLogControllerTest(InitializeMockCodeKeyLogFixture initializeMockCodeKeyLogFixture)
        {
            _initializeMockCodeKeyLogFixture = initializeMockCodeKeyLogFixture;
        }

        #region Create
        [Fact]
        public async Task CodeKeyLogController_PostAsync_ReturnOkResult()
        {
            var CodekeyLogModel = _initializeMockCodeKeyLogFixture.MockData.Object.CodeKeyLogDataCreated();


            var mockCodeKeyLogModel = _initializeMockCodeKeyLogFixture.Mapper.Map<CodeKeyLog, CodeKeyLogModel>(
                  _initializeMockCodeKeyLogFixture.MockData.Object.CodeKeyLogDataCreated());
            
            _initializeMockCodeKeyLogFixture.MockDataRepository.Setup(x => x.InsertOneAsync(It.IsAny<CodeKeyLog>()))
                                                            .Returns(Task.FromResult(CodekeyLogModel));

            var controller = new CodeKeyLogController(_initializeMockCodeKeyLogFixture.MockCodeKeyLogService.Object, new NullLogger<CodeKeyLogController>());

            var result = await controller.PostAsync(mockCodeKeyLogModel);
            var resultObjectResult = result.Result as CreatedAtRouteResult;
            var CodekeyLogModelResult = resultObjectResult.Value as CodeKeyLogModel;

            //Assert
            Assert.IsAssignableFrom<CodeKeyLogModel>(CodekeyLogModelResult);
            Assert.True(CodekeyLogModel.AccountId == CodekeyLogModelResult.AccountId);
        }

        [Fact]
        public async Task CodeKeyLogController_PostAsync_ReturnBadRequest()
        {
            // Arrange 
            var controller = new CodeKeyLogController(_initializeMockCodeKeyLogFixture.MockCodeKeyLogService.Object, new NullLogger<CodeKeyLogController>());

            //Act
            var result = await controller.PostAsync(null);
            var resultObjectResult = result.Result as BadRequestObjectResult;

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status400BadRequest);
        }
        #endregion

        #region GetById
        [Fact]
        public async Task CodeKeyLogController_GetByAccountId_ReturnOkResult()
        {
            var CodekeyLogModel = _initializeMockCodeKeyLogFixture.MockData.Object.MockCodeKeyLogs();
            var accountID = CodekeyLogModel.Select(x=>x.AccountId).FirstOrDefault();
            var eventId = CodekeyLogModel.Select(x => x.EventId).FirstOrDefault();


            _initializeMockCodeKeyLogFixture.MockDataRepository.Setup(x => x.FilterBy(model => model.AccountId == accountID && model.EventId== eventId, null, null))
               .ReturnsAsync(CodekeyLogModel);

           
            var controller = new CodeKeyLogController(_initializeMockCodeKeyLogFixture.MockCodeKeyLogService.Object, new NullLogger<CodeKeyLogController>());

            var result = await controller.GetCodeKeyLogsByAccount(accountID,eventId);

            var resultObjectResult = result.Result as OkObjectResult;
            Assert.IsType<OkObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status200OK);
        }

        [Fact]
        public async Task CodeKeyLogControlle_GetByEventId_ReturnBadRequest()
        {
            // Arrange 
            var controller = new CodeKeyLogController(_initializeMockCodeKeyLogFixture.MockCodeKeyLogService.Object, new NullLogger<CodeKeyLogController>());

            //Act
            var result = await controller.GetCodeKeyLogsByAccount(null,null);
            var resultObjectResult = result.Result as BadRequestObjectResult;

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status400BadRequest);
        }
        #endregion
    }
}
