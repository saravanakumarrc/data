﻿using codekey.service.api.controllers;
using codekey.service.data.entities;
using codekey.service.service.model;
using codekey.service.shared.constants.paging;
using codekey.service.unit.tests.mocks;
using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Xunit;

namespace codekey.service.unit.tests.controllers
{
    public class CodeKeyValueControllerTest : IClassFixture<InitializeMockCodeKeyValueFixture>
    {
        readonly InitializeMockCodeKeyValueFixture _initializeMockCodeKeyValueFixture;
        readonly QueryStringParams _queryStringParams;

        public CodeKeyValueControllerTest(InitializeMockCodeKeyValueFixture initializeMockCodeKeyValueFixture)
        {
            _initializeMockCodeKeyValueFixture = initializeMockCodeKeyValueFixture;
            _queryStringParams = initializeMockCodeKeyValueFixture.MockQueryStringParams.Object;
        }

        #region Create
        [Fact]
        public async Task CodeKeyValueController_PostAsync_ReturnOkResult()
        {
            var codeKeyValueModel = _initializeMockCodeKeyValueFixture.MockData.Object.CodeValueDataCreated();


            var mockCodeKeyValueModel = _initializeMockCodeKeyValueFixture.Mapper.Map<CodeKeyValue, CodeKeyValueModel>(
                  _initializeMockCodeKeyValueFixture.MockData.Object.CodeValueDataCreated());

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.InsertOneAsync(It.IsAny<CodeKeyValue>()))
                                                            .Returns(Task.FromResult(codeKeyValueModel));

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            var result = await controller.PostAsync(mockCodeKeyValueModel);
            var resultObjectResult = result.Result as CreatedAtRouteResult;
            var CodeKeyValueModel = resultObjectResult.Value as CodeKeyValueModel;

            //Assert
            Assert.IsAssignableFrom<CodeKeyValueModel>(CodeKeyValueModel);
            Assert.True(CodeKeyValueModel.AccountId == codeKeyValueModel.AccountId);
        }

        [Fact]
        public async Task CodeKeyValueController_GetAll_ReturnBadRequest()
        {
            // Arrange 
            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.PostAsync(null);
            var resultObjectResult = result.Result as BadRequestObjectResult;

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status400BadRequest);
        }
        #endregion

        #region GetById
        [Fact]
        public async Task CodeKeyValueController_GetByAccountId_ReturnOkResult()
        {
            var codeKeyValueModel = _initializeMockCodeKeyValueFixture.MockData.Object.GetExistingMockCodeKeyValue();
            var accountId = codeKeyValueModel.Select(x=>x.AccountId).FirstOrDefault();

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.FilterBy(model => model.AccountId == accountId, model =>model))
               .ReturnsAsync(codeKeyValueModel);

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            var result = await controller.GetByAccountIdAsync(accountId);

            var resultObjectResult = result.Result as OkObjectResult;
            Assert.IsType<OkObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status200OK);
        }

        [Fact]
        public async Task CodeKeyValueController_GetByAccountId_ReturnBadRequest()
        {
            // Arrange 
            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.GetByAccountIdAsync(null);
            var resultObjectResult = result.Result as BadRequestObjectResult;

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status400BadRequest);
        }

        #endregion

        #region PutAsync
        [Fact]
        public async Task CodeKeyValueController_Update_ReturnsOkResult()
        {
            // Arrange 
            var codeKeyToBeUpdate = _initializeMockCodeKeyValueFixture.MockData.Object.GetMockCodekeyValueToBeUpdate();
            var accountId = codeKeyToBeUpdate.AccountId;

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.FindOneAsync(model => model.AccountId == accountId))
                                                            .Returns(Task.FromResult(codeKeyToBeUpdate));


            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.ReplaceOneAsync(_initializeMockCodeKeyValueFixture.MockData.Object.GetMockCodekeyValueToBeUpdate()))
                                                                    .Returns(() =>
                                                                    {
                                                                        return Task.FromResult(codeKeyToBeUpdate);
                                                                    });

            var mockedCodekKeyValuetModel = _initializeMockCodeKeyValueFixture.Mapper.Map<CodeKeyValue, CodeKeyValueModel>(codeKeyToBeUpdate);

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());


            //Act            
            var result = await controller.Update(mockedCodekKeyValuetModel);

            //Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
        }
        [Fact]
        public async Task CodeKeyValueController_Update_ReturnBadRequest()
        {
            // Arrange 
            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.Update(null);
            var resultObjectResult = result.Result as BadRequestObjectResult;


            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status400BadRequest);
        }

        [Fact]
        public async Task CodeKeyValueController_Update_NotFoundRequest()
        {
            // Arrange 
            var CodekKeyValueToBeUpdate = _initializeMockCodeKeyValueFixture.MockData.Object.GetMockCodekeyValueToBeUpdate();
            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());
            var CodeKeyValueModel = _initializeMockCodeKeyValueFixture.Mapper.Map<CodeKeyValue, CodeKeyValueModel>(CodekKeyValueToBeUpdate);

            //Act
            var result = await controller.Update(CodeKeyValueModel);
            var resultObjectResult = result.Result as NotFoundObjectResult;


            //Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status404NotFound);
        }
        #endregion

        #region GetDataValue
        [Fact]
        public async Task CodeKeyValueController_GetDataValue_ReturnDataValueModel()
        {
            var accountId = "1";
            var codeKey = "UNIT";

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.GetDataValuesAsync(accountId, codeKey, _queryStringParams))
                .ReturnsAsync(_initializeMockCodeKeyValueFixture.MockData.Object.GetMockDataValuesWithPaging());

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.GetDataValueAsync(accountId, codeKey, _queryStringParams);

            var resultObjectResult = result.Result as OkObjectResult;

            var dataValueModelResult = resultObjectResult.Value as PagedResponseList<DataValueModel>;

            //Assert
            Assert.IsAssignableFrom<ActionResult<PagedResponseList<DataValueModel>>>(result);
            Assert.True(dataValueModelResult.Data[0].CodeId == _initializeMockCodeKeyValueFixture.MockData.Object.GetMockDataValue().CodeId);

        }

        [Fact]
        public async Task CodeKeyValueController_GetDataValue_ReturnOkResult()
        {
            var accountId = "1";
            var codeKey = "UNIT";

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.GetDataValuesAsync(accountId, codeKey, _queryStringParams))
                .ReturnsAsync(_initializeMockCodeKeyValueFixture.MockData.Object.GetMockDataValuesWithPaging());

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.GetDataValueAsync(accountId, codeKey, _queryStringParams);

            var resultObjectResult = result.Result as OkObjectResult;

            var dataValueModelResult = resultObjectResult.Value as PagedResponseList<DataValueModel>;

            //Assert
            Assert.IsType<OkObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status200OK);
        }

        [Fact]
        public async Task CodeKeyValueController_GetDataValue_ReturnBadRequest()
        {
            var accountId = "";
            var codeKey = "UNIT";

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.GetDataValuesAsync(accountId, codeKey, _queryStringParams))
                .ReturnsAsync(_initializeMockCodeKeyValueFixture.MockData.Object.GetMockDataValuesWithPaging());

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.GetDataValueAsync(accountId, codeKey, _queryStringParams);

            var resultObjectResult = result.Result as BadRequestObjectResult;

            //Assert
            Assert.IsType<BadRequestObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status400BadRequest);
        }

        [Fact]
        public async Task CodeKeyValueController_GetDataValue_ReturnNotFound()
        {
            var accountId = "2";
            var codeKey = "UNIT";

            _initializeMockCodeKeyValueFixture.MockDataRepository.Setup(x => x.GetDataValuesAsync(accountId, codeKey, _queryStringParams))
                .ReturnsAsync(new PagedResponseList<DataValue>(new List<DataValue>(), 0, 1, 50));

            var controller = new CodeKeyValueController(_initializeMockCodeKeyValueFixture.MockCodeKeyValueService.Object, new NullLogger<CodeKeyValueController>());

            //Act
            var result = await controller.GetDataValueAsync(accountId, codeKey, _queryStringParams);

            var resultObjectResult = result.Result as NotFoundObjectResult;
            //Assert
            Assert.IsType<NotFoundObjectResult>(result.Result);
            Assert.True(resultObjectResult.StatusCode == StatusCodes.Status404NotFound);
        }
        #endregion
    }
}
