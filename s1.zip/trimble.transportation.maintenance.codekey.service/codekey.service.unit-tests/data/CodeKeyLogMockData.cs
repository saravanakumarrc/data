﻿using codekey.service.data.entities;
using System;
using System.Collections.Generic;

namespace codekey.service.unit.tests.data
{
    public class CodeKeyLogMockData
    {
        public CodeKeyLog CodeKeyLogDataCreated()
        {
            return MockCodeKeyLog();
        }
        private CodeKeyLog MockCodeKeyLog()
        {
            return new CodeKeyLog()
            {
                EventId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                Status = "Success",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                AccountId= "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                Details = new CodeKeyLogDetail[] { MockDetails() }
            };
        }
        private CodeKeyLogDetail MockDetails()
        {
            CodeKeyLogDetail detail = new CodeKeyLogDetail()
            {
               MappingKey="PAYMENT",
               StatusCode=401,
               Error="payment type can't be matched"
            };
            return detail;
        }
        public  IEnumerable<CodeKeyLog> MockCodeKeyLogs()
        {
            return new List<CodeKeyLog>()
            {
              new CodeKeyLog()
              {
                EventId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                AccountId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                Status = "Success",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                 Details = new CodeKeyLogDetail[] { MockDetails() }
              }
            };

        }
        public CodeKeyLog GetExistingMockKeyLog()
        {
            return new CodeKeyLog()
            {
                EventId = "d1234556",
                AccountId = "66615a40-0b4c-482e-bc51-51538f6c3899",
                Status = "Failure",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                Details = new CodeKeyLogDetail[] { MockDetails() }
            };
        }
        public CodeKeyLog PostMockKeyLog()
        {
            return new CodeKeyLog()
            {
                EventId = "d7b60c3a-dbe7-4498-b203-55c9dc7929102",
                AccountId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                Status = "Success",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                Details = new CodeKeyLogDetail[] { MockDetails() }
            };
        }
        public CodeKeyLog GetMockCodeKeyLogForToBeUpdate()
        {
            return new CodeKeyLog()
            {
                EventId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                AccountId = "66615a40-0b4c-482e-bc51-51538f6c3858",
                Status = "Failure",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                Details = new CodeKeyLogDetail[] { MockDetails() }
            };

        }

    }
}
