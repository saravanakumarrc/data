﻿using codekey.service.data.entities;
using System;
using System.Collections.Generic;

namespace codekey.service.unit.tests.data
{
    public class CodeKeyMockData
    {
        public CodeKey CodeKeyDataCreated()
        {
            return MockCodeKey();
        }
        private CodeKey MockCodeKey()
        {
            return new CodeKey()
            {
                Id = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                IsActive = true,
                MappingKey = "FEECHARGECAT",
                ResourceUrl = "maintenance/v1/integrations/taxrates?chgCateg=FEE",
                SearchUrl = "maintenance/v1/codekey/accounts/{accountId}/codekeyvalues/FEECHARGECAT",
                DataMapping = MockDataMapping()
            };
        }
        private DataMapping MockDataMapping()
        {
            DataMapping dataMapping = new DataMapping()
            {
                CodeId = "id",
                Code = "code",
                Description = "description"
            };
            return dataMapping;
        }
        public  IEnumerable<CodeKey> MockCodeKeys()
        {
            return new List<CodeKey>()
            {
                new CodeKey()
                {
                    Id = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                    IsActive = true,
                    MappingKey = "FEECHARGECAT",
                    ResourceUrl = "maintenance/v1/integrations/taxrates?chgCateg=FEE",
                    SearchUrl = "maintenance/v1/codekey/accounts/{accountId}/codekeyvalues/FEECHARGECAT",
                    DataMapping = MockDataMapping()
                }
            };
        }
    }
}
