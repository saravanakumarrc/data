﻿using codekey.service.data.entities;
using codekey.service.shared.constants.paging;
using System;
using System.Collections.Generic;

namespace codekey.service.unit.tests.data
{
    public class CodeKeyValueMockData
    {
        public CodeKeyValue CodeValueDataCreated()
        {
            return MockCodeKeyValue();
        }

        private CodeKeyValue MockCodeKeyValue()
        {
            return new CodeKeyValue()
            {
                AccountId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                IsActive = true,
                MappingKey = "CUSTOMER",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                DataValues = new DataValue[] { GetMockDataValue() }
            };

        }
        public DataValue GetMockDataValue()
        {
            DataValue dataValue = new DataValue()
            {
                CodeId = "605dd99f5e899b0dd12b31e6",
                Code = "bye",
                Description = "credit"
            };
            return dataValue;
        }

        public IEnumerable<CodeKeyValue> GetExistingMockCodeKeyValue()
        {
            return new List<CodeKeyValue>()
            {
                new CodeKeyValue()
               {
                   AccountId = "d7b60c3a-dbe7-4498-b203-55c9dc7929101",
                IsActive = true,
              
                MappingKey = "CUSTOMER",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                DataValues = new DataValue[] { GetMockDataValue() }
               }
            };

        }
        public CodeKeyValue GetMockCodekeyValueToBeUpdate()
        {
            return new CodeKeyValue()
            {
                AccountId = "d7b60c3a-dbe7-4498-b203-55c9dc7929100",
                IsActive = true,
                Id = "620a2f7ed734bc13706a5783",
                MappingKey = "CUSTOMER",
                ModifiedDate = DateTime.UtcNow,
                ModifiedBy = "admin",
                CreatedDate = DateTime.UtcNow,
                CreatedBy = "admin",
                DataValues = new DataValue[] { GetMockDataValue() }
            };

        }

        public PagedResponseList<DataValue> GetMockDataValuesWithPaging()
        {
            var result = new PagedResponseList<DataValue>(new List<DataValue> { GetMockDataValue() }, 1,  1, 10);
            return result;
        }
    }
}
