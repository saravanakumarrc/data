﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.service;
using codekey.service.service.mapping;
using codekey.service.unit.tests.data;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;

namespace codekey.service.unit.tests.mocks
{
    public class InitializeMockCodeKeyFixture
    {
        public Mock<CodeKeyService> MockCodeKeyService { get; }
        public Mock<IMongoRepository<CodeKey>> MockDataRepository { get; }
        public Mock<CodeKeyMockData> MockData { get; }
        public IMapper Mapper { get; }


        public InitializeMockCodeKeyFixture()
        {
            MockData = new Mock<CodeKeyMockData>();
            Mapper = AutoMapperConfiguration.Configure();
            MockDataRepository = new Mock<IMongoRepository<CodeKey>>();
            MockCodeKeyService = new Mock<CodeKeyService>(new NullLogger<CodeKeyLogService>(),
                                        MockDataRepository.Object, Mapper)
            { CallBase = true };
        }
    }
}
