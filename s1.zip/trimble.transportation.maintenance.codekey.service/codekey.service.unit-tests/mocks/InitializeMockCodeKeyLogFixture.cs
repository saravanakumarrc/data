﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.service;
using codekey.service.service.mapping;
using codekey.service.unit.tests.data;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;

namespace codekey.service.unit.tests.mocks
{
    public class InitializeMockCodeKeyLogFixture
    {
        public Mock<CodeKeyLogService> MockCodeKeyLogService { get; }
        public Mock<IMongoRepository<CodeKeyLog>> MockDataRepository { get; }
        public Mock<CodeKeyLogMockData> MockData { get; }
        public IMapper Mapper { get; }


        public InitializeMockCodeKeyLogFixture()
        {
            MockData = new Mock<CodeKeyLogMockData>();
            Mapper = AutoMapperConfiguration.Configure();
            MockDataRepository = new Mock<IMongoRepository<CodeKeyLog>>();
            MockCodeKeyLogService = new Mock<CodeKeyLogService>(new NullLogger<CodeKeyLogService>(),
                                        MockDataRepository.Object, Mapper)
            { CallBase = true };
        }
    }
}
