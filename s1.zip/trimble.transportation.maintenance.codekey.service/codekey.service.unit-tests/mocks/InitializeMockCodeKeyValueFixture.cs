﻿using AutoMapper;
using codekey.service.data.entities;
using codekey.service.repository.abstracts;
using codekey.service.service;
using codekey.service.service.mapping;
using codekey.service.shared.constants.paging;
using codekey.service.unit.tests.data;
using Microsoft.Extensions.Logging;
using Microsoft.Extensions.Logging.Abstractions;
using Moq;
using System.Collections.Generic;

namespace codekey.service.unit.tests.mocks
{
    public class InitializeMockCodeKeyValueFixture
    {
        public Mock<CodeKeyValueService> MockCodeKeyValueService { get; }
        public Mock<ICodeKeyValueRepository> MockDataRepository { get; }
        public Mock<CodeKeyValueMockData> MockData { get; }
        public IMapper Mapper { get; }
        public Mock<QueryStringParams> MockQueryStringParams { get; }


        public InitializeMockCodeKeyValueFixture()
        {
            MockData = new Mock<CodeKeyValueMockData>();
            Mapper = AutoMapperConfiguration.Configure();
            MockDataRepository = new Mock<ICodeKeyValueRepository>();
            MockCodeKeyValueService = new Mock<CodeKeyValueService>(new NullLogger<CodeKeyValueService>(),
                                        MockDataRepository.Object, Mapper)
            { CallBase = true };
            MockQueryStringParams = new Mock<QueryStringParams>();
            MockQueryStringParams.Setup(x => x.PageNo).Returns(1);
            MockQueryStringParams.Setup(x => x.PageSize).Returns(10);
            MockQueryStringParams.Setup(x => x.SortBy).Returns(new List<Sorting>());
        }
    }
}
