#!/bin/bash
ENV=${APP_ENV}
echo $ENV

export LOG_TRACE=$(cat /kvmnt/$ENV-LOG-TRACE)
echo $LOG_TRACE

export DatabaseSettings__ConnectionString=$(cat /kvmnt/$ENV-DB-CONNECTION-STRING)
export DatabaseSettings__DatabaseName=$(cat /kvmnt/$ENV-DATABASE-NAME)
export SeriLog__MinimumLevel__Default=$(cat /kvmnt/$ENV-LOG-MINIMUM-LEVEL-DEFAULT)

dotnet codekey.service.api.dll
